ls
exit
lsblk
poweroff
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
cd /opt/scripts
ls
ls -l
vi backup_full.sh
cat backup_full.sh
cat backup_full.sh.swp
vi backup_full.sh
 backup_full.sh -help
 /backup_full.sh -help
 /backup_full.sh --help
. /backup_full.sh --help
 ./backup_full.sh --help
poweroff
