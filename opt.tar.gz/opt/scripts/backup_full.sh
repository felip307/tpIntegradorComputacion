#!/bin/bash

ORIGEN="$1"
DESTINO="$2"

if [ "$1" = "--help"  ]; then
	echo "Uso: $0 <origen> <destino>"
	echo ""
	echo "Realiza un backup comprimido (.tar.gz) del directorio de origen"
	echo "y lo guarda en el directorio de destino, con el nombre de la fecha"
	echo ""
	echo "Argumentos:"
	echo "<origen> Directorio a hacer el backup (ej: /var/log)"
	echo "<destino> Directorio donde guardar el backup (ej: /backup_dir)"
	echo ""
	echo "Ejemplo:"
	echo "$0 /var/log /backup_dir"
	echo ""
	exit 0

fi

#validamos q se pasaron los dos argumentos
if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
	echo "Error: Faltan argumentos"
	echo "Uso: $0 <origen> <destino>"
	exit 1
fi

#valifamos que el origen existe
if [ ! -e "$ORIGEN" ]; then
	echo "Error: el origen $ORIGEN no existe"
	exit 1
fi

#validamos que el destino existe
if [ ! -d "$DESTINO" ]; then
	echo "Error: el destino $DESTINO no existe o no es un directorio"
	exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")

ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "${DESTINO}/${ARCHIVO}" "$ORIGEN"

echo "Backup creado: ${DESTINO}/${ARCHIVO}"

